﻿namespace AEuklidesa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Wpisz A");
            int a = Convert.ToInt32 (Console.ReadLine());
            Console.WriteLine("Wpisz B");
            int b = Convert.ToInt32 (Console.ReadLine());

            int NWD = obliczenia(a, b);
            Console.WriteLine($"Wspólny dzielnik {a} i {b} = {NWD} ");
            static int obliczenia (int a, int b)
            {
                while(a != b)
                {
                    if (a > b)
                    {
                        a = a - b;
                    }
                    else
                    {
                        b = b - a;
                    }
                }
                return a;
            }
        }
    }
}