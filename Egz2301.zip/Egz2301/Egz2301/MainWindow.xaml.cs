﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Egz2301
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string wygHaslo;
        public MainWindow()
        {
            InitializeComponent();
        }
        private void GenerowanieHasla_Click(object sender, RoutedEvent e)
        {
            int iloscZnaków = 0;
            if(!int.TryParse(IloscZnakow.Text, out iloscZnaków))
            {
                MessageBox.Show("Podaj dobra ilosc znaków");
                return;
            }
            if(iloscZnaków < 0)
            {
                MessageBox.Show("Minimalna liczba znakow to 8");
                return;
            }
            StringBuilder haslo = new StringBuilder();
            Random rand = new Random();
            if(malewielkie.IsChecked == true)
            {
                char litera = (char)rand.Next('a', 'z' + 1);
                haslo.Append(litera);
            }
            if (cyfry.IsChecked == true)
            {
                char cyfra = (char)rand.Next('0', '9' + 1);
                haslo.Append(cyfra);
            }
            if (znaki.IsChecked == true)
            {
                string specjalne = "!@#$%^&*()_+-=";
                char znak = specjalne[rand.Next(specjalne.Length)];
                haslo.Append(znak);
            }
            while(haslo.Length <iloscZnaków) 
            {
                char znak = (char)rand.Next('!', 'z' + 1);
                if(char.IsLetterOrDigit(znak))
                {
                    haslo.Append(znak);
                }
            }
            wygHaslo = haslo.ToString();
            MessageBox.Show("wygenerowane haslo" + haslo.ToString());
        }
        
    }
}
